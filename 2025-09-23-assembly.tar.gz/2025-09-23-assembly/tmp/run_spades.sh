set -e
true
true
/usr/local/bin/spades-hammer /home/matt/2025-09-23-assembly/tmp/corrected/configs/config.info
/usr/local/miniconda/bin/python /usr/local/share/spades/spades_pipeline/scripts/compress_all.py --input_file /home/matt/2025-09-23-assembly/tmp/corrected/corrected.yaml --ext_python_modules_home /usr/local/share/spades --max_threads 16 --output_dir /home/matt/2025-09-23-assembly/tmp/corrected --gzip_output
true
true
/usr/local/bin/spades-core /home/matt/2025-09-23-assembly/tmp/K21/configs/config.info
/usr/local/bin/spades-core /home/matt/2025-09-23-assembly/tmp/K33/configs/config.info
/usr/local/bin/spades-core /home/matt/2025-09-23-assembly/tmp/K55/configs/config.info
/usr/local/miniconda/bin/python /usr/local/share/spades/spades_pipeline/scripts/copy_files.py /home/matt/2025-09-23-assembly/tmp/K55/before_rr.fasta /home/matt/2025-09-23-assembly/tmp/before_rr.fasta /home/matt/2025-09-23-assembly/tmp/K55/assembly_graph_after_simplification.gfa /home/matt/2025-09-23-assembly/tmp/assembly_graph_after_simplification.gfa /home/matt/2025-09-23-assembly/tmp/K55/final_contigs.fasta /home/matt/2025-09-23-assembly/tmp/contigs.fasta /home/matt/2025-09-23-assembly/tmp/K55/first_pe_contigs.fasta /home/matt/2025-09-23-assembly/tmp/first_pe_contigs.fasta /home/matt/2025-09-23-assembly/tmp/K55/strain_graph.gfa /home/matt/2025-09-23-assembly/tmp/strain_graph.gfa /home/matt/2025-09-23-assembly/tmp/K55/scaffolds.fasta /home/matt/2025-09-23-assembly/tmp/scaffolds.fasta /home/matt/2025-09-23-assembly/tmp/K55/scaffolds.paths /home/matt/2025-09-23-assembly/tmp/scaffolds.paths /home/matt/2025-09-23-assembly/tmp/K55/assembly_graph_with_scaffolds.gfa /home/matt/2025-09-23-assembly/tmp/assembly_graph_with_scaffolds.gfa /home/matt/2025-09-23-assembly/tmp/K55/assembly_graph.fastg /home/matt/2025-09-23-assembly/tmp/assembly_graph.fastg /home/matt/2025-09-23-assembly/tmp/K55/final_contigs.paths /home/matt/2025-09-23-assembly/tmp/contigs.paths
true
/usr/local/miniconda/bin/python /usr/local/share/spades/spades_pipeline/scripts/breaking_scaffolds_script.py --result_scaffolds_filename /home/matt/2025-09-23-assembly/tmp/scaffolds.fasta --misc_dir /home/matt/2025-09-23-assembly/tmp/misc --threshold_for_breaking_scaffolds 3
true
